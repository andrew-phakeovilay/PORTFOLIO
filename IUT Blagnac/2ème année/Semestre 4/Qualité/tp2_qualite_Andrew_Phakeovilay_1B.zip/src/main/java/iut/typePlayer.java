package iut;

public class typePlayer {
    public static final int MELEE = 2;
    public static final int RANGED = 20;
}
