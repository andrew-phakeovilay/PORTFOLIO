package iut;

public class Faction {
    private String name;

    public Faction(String factionName){
        this.name = factionName;
    };

    /* Retourne le nom de la faction
     *
     */
    public String getName(){
        return this.name;
    }
}
