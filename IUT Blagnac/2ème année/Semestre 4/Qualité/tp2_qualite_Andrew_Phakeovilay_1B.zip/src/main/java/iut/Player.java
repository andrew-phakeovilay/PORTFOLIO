package iut;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.lang.Math.abs;

class Player {
    private int healthPoints;
    private boolean alive;
    private List<Faction> factions;
    private int position;
    private int distanceATK;

    public Player(int type) {
        this.healthPoints = 100;
        this.alive = true;
        this.factions = new ArrayList<Faction>();
        this.position = 0;
        this.distanceATK = type;
    }
    public Player(int type, int position){
        this.healthPoints = 100;
        this.alive = true;
        this.factions = new ArrayList<Faction>();
        this.position = position;
        this.distanceATK = type;
    }

    /** Retourne la position du joueur
     * @return la position
     */
    public int getPosition(){
        return this.position;
    }

    /** Retourne la distance d'attaque du joueur
     * @return la distance d'attaque
     */
    public int getDistanceATK(){
        return this.distanceATK;
    }

    /** Retourne les points de vie du joueur
     * @return les points de vie
     */
    public int getHealth(){
        return this.healthPoints;
    }

    /** Retourne si le joueur est vivant ou non
     * @return boolean true
     * sinon false
     */
    public boolean isAlive(){
        return this.alive;
    }

    /** Inflige des dégats à un autre joueur
     * @param opponent l'autre joueur
     */
    public void hit(Player opponent){
        if(opponent.isAlive() && !isAlly(opponent) && distanceBetweenPlayers(this, opponent) <= this.distanceATK)
            opponent.removeHealth(10);
    }

    /** Retire des points de vie au joueur
     * @param healthLost nombre de points de vie à perdre
     */
    public void removeHealth(int healthLost){
        if(healthLost >= this.healthPoints){
            this.healthPoints -= this.healthPoints;
            this.alive = false;
        }
        else this.healthPoints -= healthLost;
    }

    /** Soigne le joueur avec 10 points de vie s'il est vivant ou n'a pas 100 points de vie
     *
     */
    public void heal(){
        if(isAlive() && this.healthPoints != 100){
            if(this.healthPoints > 90) this.healthPoints += 100 - this.healthPoints;
            else this.healthPoints += 10;
        }
    }

    /** Vérifie si le joueur choisi est dans la même faction que l'autre joueur
     * @return boolean true
     * sinon false
     */
    public boolean isAlly(Player ally){
        return !Collections.disjoint(getFactions(), ally.getFactions());
    }


    /** Soigne un joueur de même faction avec 10 points de vie s'il est vivant ou n'a pas 100 points de vie
     * @param ally L'autre Joueur
     */
    public void heal(Player ally){
        if(isAlly(ally)) ally.heal();
    }

    /** Retourne les factions du joueur
     * @return factions
     */
    public List<Faction> getFactions(){
        return this.factions;
    }

    /** Permet au joueur de rejoindre une nouvelle faction
     * @param faction La faction
     */
    public void joinFaction(Faction faction) {
        if(!this.factions.contains(faction)) this.factions.add(faction);
    }

    /** Permet au joueur de quitter une faction qu'il a rejoint
     * @param faction La faction
     */
    public void leaveFaction(Faction faction) {
        if(this.factions.contains(faction)) this.factions.remove(faction);
    }

    /** Permet de déplacer le joueur
     * @param movement mouvement
     */
    public void move(int movement){
        this.position += movement;
    }

    /** Donne la distance entre 2 joueurs
     * @param player1 Joueur 1
     * @param player2 Joueur 2
     */
    public int distanceBetweenPlayers(Player player1, Player player2){
        int distance = abs(player1.getPosition()) - abs(player2.getPosition());
        return abs(distance);
    }
}


