package iut;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class PlayerTest {

    @Test
    public void ShouldCreatePlayer() {
        // GIVEN
        Player player = new Player(typePlayer.MELEE);

        // WHEN
        int initialHealthPoints = player.getHealth();

        // THEN
        assertThat(initialHealthPoints).isEqualTo(100);
    }

    @Test
    public void DamageDealt(){
        // GIVEN
        Player player1 = new Player(typePlayer.MELEE);
        Player player2 = new Player(typePlayer.RANGED, 10);
        Player player3 = new Player(typePlayer.RANGED, 30);

        // WHEN
        player1.hit(player2);
        player1.move(10);
        player1.hit(player2);
        int healthPointsP2Left = player2.getHealth();

        player2.hit(player3);
        int healthPointsP3Left = player3.getHealth();
        // THEN
        assertThat(healthPointsP2Left).isEqualTo(90);
        assertThat(healthPointsP3Left).isEqualTo(90);
    }

    @Test
    public void CheckPlayerDead(){
        // GIVEN
        Player player = new Player(typePlayer.RANGED);

        // WHEN
        player.removeHealth(110);
        int healthPointsLeft = player.getHealth();
        boolean isAlive = player.isAlive();
        // THEN
        assertThat(healthPointsLeft).isEqualTo(0);
        assertThat(isAlive).isEqualTo(false);
    }

    @Test
    public void CheckPlayerHealed(){
        // GIVEN
        Player playerFullHPHealTest = new Player(typePlayer.RANGED);

        Player playerDeadHealTest = new Player(typePlayer.RANGED);
        playerDeadHealTest.removeHealth(100);

        Player playerLostHPHealTest = new Player(typePlayer.RANGED);
        playerLostHPHealTest.removeHealth(10);

        // WHEN
        playerFullHPHealTest.heal();
        int hpLeft1 = playerFullHPHealTest.getHealth();

        playerDeadHealTest.heal();
        int hpLeft2 = playerDeadHealTest.getHealth();

        playerLostHPHealTest.heal();
        int hpLeft3 = playerLostHPHealTest.getHealth();

        // THEN
        assertThat(hpLeft1).isEqualTo(100);
        assertThat(hpLeft2).isEqualTo(0);
        assertThat(hpLeft3).isEqualTo(100);
    }

    @Test
    public void CheckFactionTests() {
        // GIVEN
        Faction Fac1 = new Faction("Faction 1");
        Faction Fac2 = new Faction("Faction 2");

        Player player1Fac1 = new Player(typePlayer.RANGED);
        Player player2Fac1and2 = new Player(typePlayer.RANGED);
        player2Fac1and2.removeHealth(10);

        Player player3Fac2 = new Player(typePlayer.RANGED);

        // WHEN
        player1Fac1.joinFaction(Fac1);
        player1Fac1.joinFaction(Fac2);
        player1Fac1.leaveFaction(Fac2);

        player2Fac1and2.joinFaction(Fac1);
        player2Fac1and2.joinFaction(Fac2);

        player3Fac2.joinFaction(Fac2);

        player1Fac1.hit(player2Fac1and2);
        player1Fac1.heal(player2Fac1and2);
        int healthP2 = player2Fac1and2.getHealth();

        player1Fac1.hit(player3Fac2);
        player2Fac1and2.hit(player3Fac2);
        player1Fac1.heal(player3Fac2);
        int healthP3 = player3Fac2.getHealth();

        // THEN
        assertThat(healthP3).isEqualTo(90);
        assertThat(healthP2).isEqualTo(100);
    }
}

