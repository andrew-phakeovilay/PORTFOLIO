package test.java;

import static org.junit.Assert.assertEquals;

import java.util.Vector;
import org.junit.jupiter.api.Test;

import main.java.Customer;
import main.java.Movie;
import main.java.Rental;

public class CustomerTest {

	@Test
	public void testNom(){
		// Given
		Customer test = new Customer("andrew", new Vector<>());
		// When
		String nomTest = test.getName();
		// Then
		assertEquals(nomTest, "andrew");
	}


	@Test
	public void testRental(){
		// Given
		Customer test = new Customer("andrew", new Vector<>());
		Movie movieTest = new Movie ("Spider-man", Movie.REGULAR);
		Rental rentalTest = new Rental (movieTest, 5);
		// When
		test.addRental(rentalTest);
		// Then
		assertEquals(test.getRentals(), "\t" + rentalTest.getMovie().getTitle() + "\t" + String.valueOf(rentalTest.getAmount()) + "\n");
	}

	@Test
	public void testEmptyRent() {
		// Given
		Customer test = new Customer("andrew", new Vector<>());
		// When
		
		// Then
		assertEquals(test.getRentals(), "");
	}
	
	@Test
	public void testAddRentalCheckTotalAndFrenquent() {
		// Given
		Customer test = new Customer("andrew", new Vector<>());
		Movie movieTest = new Movie ("Spider-man", Movie.REGULAR);
		Rental rentalTest = new Rental (movieTest, 5);
		// When
		test.addRental(rentalTest);
		// Then
		assertEquals(test.getFrequentRenterPoints(), 1);
		assertEquals(test.getTotalAmounth(), rentalTest.getAmount(), 0.0);
	}
}
