package main.java;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Customer {
	private String _name;
	private Vector<Rental> _rentals = new Vector<Rental>();
	private double _totalAmount;
	private int _frequentRenterPoints;

	public Customer(String name, Vector<Rental> rentals) {
		this._name = name;
		this._rentals = rentals;
		this._totalAmount = 0;
		this._frequentRenterPoints = 0;
	}

	/** Ajoute au client une location de film
	 * @param arg la location à ajouter
	 */
	public void addRental(Rental arg) {
		// add frequent renter points
		_frequentRenterPoints ++;
		// add bonus for a two day new release rental
		if ((arg.getMovie().getPriceCode() == Movie.NEW_RELEASE) && arg.getDaysRented() > 1)
			_frequentRenterPoints ++;

		_totalAmount += arg.getAmount();
		_rentals.addElement(arg);
	}

	/** Retourne les locations de film du client
	 * @return les locations de film
	 */
	public String getRentals() {
		String rentals = "";
		Iterator<Rental> rentalIterator = _rentals.iterator();
		while(rentalIterator.hasNext()) {

			Rental each = rentalIterator.next();

			rentals += "\t" + each.getMovie().getTitle() + "\t" + String.valueOf(each.getAmount()) + "\n";
		}
		return rentals;
	}

	/** Retourne le montant total du client
	 * @return le montant total du client
	 */
	public double getTotalAmounth() {
		return _totalAmount;
	}

	/** Retourne les points fréquent de location
	 * @return points
	 */
	public int getFrequentRenterPoints() {
		return _frequentRenterPoints;
	}

	/** Retourne le nom du client
	 * @return le nom
	 */
	public String getName() {
		return _name;
	}

	public String toString() {
		String result = "Rental Record for " + getName() + "\n";
		result += this.getRentals();
		// add footer lines
		result += "Amount owed is " + String.valueOf(this.getTotalAmounth()) + "\n";
		result += "You earned " + String.valueOf(this.getFrequentRenterPoints()) + " frequent renter points";
		return result;
	}

	public JFrame statementHTML() {
   
		JFrame jf = new JFrame("Customer page");
		JPanel panel = new JPanel();  
	    panel.setLayout(new FlowLayout());  
		String html = "<html>\n" +
				"  <head>\n" +
				"    <title>Customer</title>\n" +
				"  </head>\n" +
				"  <body>\n" +
				"    <h1>" + "Rental Record for " + getName() +"</h1>\n";
		for(Rental r : _rentals) {
			html += "<p>" + r.getMovie().getTitle() + " " + r.getAmount() +"</p>\n";
		}
		html += "<br>" + 
				"<p>Amount owed is " + String.valueOf(this.getTotalAmounth()) + "</p>\n" +
				"<p>You earned " + String.valueOf(this.getFrequentRenterPoints()) + "</p>\n" +
				"  </body>\n" +
				"</html>";
	    JLabel label = new JLabel(html);
	    panel.add(label);
		jf.add(panel);
		jf.setSize(500,600);
		jf.setMinimumSize(new Dimension(500, 100));
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		return jf;

	}
}
