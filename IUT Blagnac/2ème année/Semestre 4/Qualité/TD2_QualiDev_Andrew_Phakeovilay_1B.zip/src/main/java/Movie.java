package main.java;

public class Movie {
    public static final int CHILDRENS = 2;
    public static final int REGULAR = 0;
    public static final int NEW_RELEASE = 1;

    private String _title;
    private int _priceCode;

    public Movie (String title, int priceCode) {
        this._title = title;
        this._priceCode = priceCode;
    }

    /** Retourne le prix du film
     * @return le prix du film
     */
    public int getPriceCode() {
        return _priceCode;
    }

    /** Change le prix du film
     * @param arg le nouveau prix du film
     */
    public void setPriceCode(int arg) {
        _priceCode = arg;
    }

    /** Retourne le titre du film
     * @return le titre du film
     */
    public String getTitle() {
        return _title;
    }
}
