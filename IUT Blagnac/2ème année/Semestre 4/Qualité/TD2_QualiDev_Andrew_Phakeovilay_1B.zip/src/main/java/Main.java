package main.java;

import java.util.Scanner;
import java.util.Vector;

public class Main {


	public static void main(String[] args) {

		Customer aCustomer = new Customer("BILL", new Vector<Rental>());

		aCustomer.addRental(new Rental(new Movie("Back To The Future", Movie.REGULAR), 5));
		aCustomer.addRental(new Rental(new Movie("Batman", Movie.NEW_RELEASE), 10));  

		try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("t pour afficher dans la console\nh pour afficher sur le format HTML");
			String choix = scanner.nextLine();
			switch (choix) {
				case "t":
					System.out.println(aCustomer);
					break;
				case "h":
					aCustomer.statementHTML();
					break;
				default:
					System.out.println("Vous avez rien entré ou ce n'est pas bon...");
			}
		}
	}
}

/**
 * Pour éviter la régression, nous pouvons effectuer des tests unitaires, des tests de régression, des tests d'intégration, un code propre et organisé et une documentation.
 * 
 * Pour savoir si nous avons écrit suffisamment de tests, nous pouvons utiliser l'outil de test JUnit.
 */