package main.java;

public class Rental {
    private Movie _movie;
    private int _daysRented;
	private double _thisAmount;
	
    public Rental(Movie movie, int daysRented) {
        this._movie = movie;
        this._daysRented = daysRented;
		switch (this._movie.getPriceCode()) {
			case Movie.REGULAR :
				this._thisAmount += 2;
				if (this.getDaysRented() > 2)
					this._thisAmount += (this.getDaysRented() - 2) * 1.5;
				break;
			case Movie.NEW_RELEASE:
				this._thisAmount += this.getDaysRented() * 3;
				break;
			case Movie.CHILDRENS:
				this._thisAmount += 1.5;
				if (this.getDaysRented() > 3)
					this._thisAmount += (this.getDaysRented() - 3) * 1.5;
				break;
		}
    }

    /** Retourne le film
     * @return le film
     */
    public Movie getMovie() {
        return _movie;
    }

    /** Retourne la durée de la location du ticket de film
     * @return la durée de la location du ticket de film
     */
    public int getDaysRented() {
        return _daysRented;
    }
    
    /** Retourne le montant du film
     * @return le montant du film
     */
    public double getAmount() {
    	return _thisAmount;
    }
}
